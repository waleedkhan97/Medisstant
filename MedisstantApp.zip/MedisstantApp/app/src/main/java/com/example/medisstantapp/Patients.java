package com.example.medisstantapp;

public class Patients {


    public String fullname, email, age, contact;

    public Patients() {
    }

    public Patients(String fullname, String email, String age, String contact) {
        this.fullname = fullname;
        this.email = email;
        this.age = age;
        this.contact = contact;
    }
}
