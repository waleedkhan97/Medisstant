package com.example.medisstantapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

public class LoginAct extends AppCompatActivity  implements View.OnClickListener{


    EditText emailid;
    EditText passwordid;
    Button fgbtn;
    Button loginbtn;
    Button regbutton;
    ProgressDialog progressDialog;
    FirebaseAuth firebaseAuth;
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        progressDialog=new ProgressDialog(this);
        firebaseAuth=FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser()!=null)
        {
            finish();
           // startActivity(new Intent(getApplicationContext(),HomeAct.class));
        }


        emailid= findViewById(R.id.emailid);
        passwordid= findViewById(R.id.passwordid);
        fgbtn= findViewById(R.id.fgbtn);
        loginbtn= findViewById(R.id.loginbtn);
        regbutton= findViewById(R.id.regbutton);


        loginbtn.setOnClickListener(this);
        regbutton.setOnClickListener(this);


    }

    private void usersignin()
    {
        String email=emailid.getText().toString().trim();
        String password=passwordid.getText().toString().trim();


        if (TextUtils.isEmpty(email))
        {
            emailid.setError("Enter your email");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordid.setError("Enter your password");
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            emailid.setError("Enter a valid email");
            return;
        }

        progressDialog.setMessage("Logging in...");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {

                if(task.isSuccessful())
                {
                    finish();
                    progressDialog.dismiss();
                    //startActivity(new Intent(getApplicationContext(),HomeAct.class));
                }

            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();

        if(firebaseAuth.getCurrentUser()!=null)
        {
            finish();
            //startActivity(new Intent(this, HomeAct.class));
        }
    }

    @Override
    public void onClick(View view) {
        if(view==loginbtn)
        {
            usersignin();

        }

        if(view==regbutton)
        {
            finish();
            startActivity(new Intent(this, RegisterAct.class));
        }
    }
}
