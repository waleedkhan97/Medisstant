package com.example.medisstantapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegisterAct extends AppCompatActivity implements View.OnClickListener {



    Button signup;
    EditText login;
    EditText password;
    Button signin;
    public EditText idFullname;
    EditText idContact;
    EditText idAge;
    ProgressDialog progressDialog;
    FirebaseAuth firebaseAuth;
    DatabaseReference ref;
    long maxid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        firebaseAuth=FirebaseAuth.getInstance();
        ref= FirebaseDatabase.getInstance().getReference().child("Patients");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    maxid=(dataSnapshot.getChildrenCount());

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        if(firebaseAuth.getCurrentUser()!=null)
        {
            finish();
            //startActivity(new Intent(getApplicationContext(),HomeAct.class));
        }

        progressDialog=new ProgressDialog(this);

        login= findViewById(R.id.emailadd);
        password= findViewById(R.id.passwordid);
        idFullname= findViewById(R.id.idFullname);
        idContact= findViewById(R.id.idContact);
        idAge= findViewById(R.id.idAge);
        signin= findViewById(R.id.fgbtn);
        signup= findViewById(R.id.loginbtn);
        idFullname.requestFocus();

        signup.setOnClickListener(this);
        signin.setOnClickListener(this);
    }

    public void signup() {
        final String email = login.getText().toString().trim();
        String pass = password.getText().toString().trim();
        final String fullname=idFullname.getText().toString().trim();
        final String contact=idContact.getText().toString().trim();
        final String age=idAge.getText().toString().trim();


        if(TextUtils.isEmpty(fullname))
        {
            idFullname.setError("This field cannot be empty");
            return;
        }
        if(TextUtils.isEmpty(contact))
        {
            idContact.setError("This field cannot be empty");
            return;
        }
        if(TextUtils.isEmpty(age))
        {
            idAge.setError("Please enter your age");
            return;
        }

        if (TextUtils.isEmpty(email))
        {
            login.setError("Please enter your email address");
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            login.setError("Enter a valid email");
            return;
        }

        if (TextUtils.isEmpty(pass))
        {
            Toast.makeText(this, "Please enter your password", Toast.LENGTH_LONG).show();
            return;
        }
        if (password.length() < 6)
        {
            Toast.makeText(this, "Passwords cannot be less than 6 characters", Toast.LENGTH_LONG).show();
            return;
        }
        if(contact.length()!=11)
        {
            idContact.setError("Enter a valid number");
            return;
        }





        progressDialog.setMessage("Registering, please wait");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override

            public void onComplete(@NonNull Task<AuthResult> task) {
            progressDialog.dismiss();
                if(task.isSuccessful())
                {
                    Patients patients=new Patients(
                            fullname, email, age, contact);

                    FirebaseDatabase.getInstance().getReference("Patients").child(String.valueOf(maxid)).setValue(patients).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(RegisterAct.this, "Registered Successfully", Toast.LENGTH_LONG).show();
                            }
                            else {
                                if(task.getException() instanceof FirebaseAuthUserCollisionException)
                                {
                                    Toast.makeText(getApplicationContext(),"This email is already registered",Toast.LENGTH_LONG).show();
                                }
                                else
                                {
                                    Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                }

                            }
                        }
                    });


                    finish();
                   // startActivity(new Intent(getApplicationContext(),HomeAct.class));


                }

                else
                {
                    Toast.makeText(RegisterAct.this,"Registration failed, try again",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    @Override
    public void onClick(View view) {
        if(view==signup)
        {
            signup();
        }

        if(view==signin)
        {

            startActivity(new Intent(this, LoginAct.class));
        }
    }
}
